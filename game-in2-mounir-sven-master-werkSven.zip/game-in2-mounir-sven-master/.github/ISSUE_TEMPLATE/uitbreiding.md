---
name: Uitbreiding
about: Idee voor uitbreiding van je game
title: 'Uitbreiding: [korte beschrijving]'
labels: enhancement
assignees: ''

---

**Hoe moet de game worden uitgebreid?**
Beschrijf wat er veranderd moet worden.
