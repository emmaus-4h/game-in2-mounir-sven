---
name: Verbetering
about: Een verbetering van bestaande gamefunctionaliteit
title: 'Verbetering: [korte beschrijving]'
labels: enhancement
assignees: ''

---

**Vind je iets jammer of erger je je ergens aan?**
Korte beschrijving van het 'probleem'

**Wat is jouw voorgestelde oplossing**
Wat zou er moeten gebeuren.
